# XVR Android (starter port)

Native Android Java starter port of the supplied Windows WPF XVR IMAP project.

## Build APK from an Android phone (GitHub Actions)
1. Sign in to GitHub in a browser and create a **public** repository (for example `xvr-android`).
2. Upload the contents of this project folder to the repository root (the `app`, `gradle.properties`, `settings.gradle`, `build.gradle`, and `.github` entries; do not upload the enclosing `XVR-Android` folder as an extra nested level).
3. Open the repository's **Actions** tab and enable workflows if prompted.
4. Select **Build XVR APK** and tap **Run workflow**. A push to `main` also starts a build.
5. When the run finishes successfully, open it and download the `XVR-debug-APK` artifact. GitHub may require downloading the artifact ZIP and extracting the APK.

The workflow uses GitHub-hosted Linux runners, Java 17, and Gradle 8.9; Android SDK components are installed/resolved by the Android Gradle Plugin during the build.

## Included in this starter
- Dark English login UI; email, password, optional IMAP username and custom server.
- Provider mappings from the supplied Windows source, including the complete DTI legacy domain routing table. For `@eurus.dti.ne.jp`, the app now selects `imap.cm.dream.jp` (IMAPS port 993). Unknown domains still use an `imap.<domain>` fallback; that fallback is not guaranteed to be correct.
- IMAPS port 993 with TLS certificate/hostname validation enabled.
- Inbox latest-message paging (25 at a time), subject/from search, text/HTML-to-text message reading.
- User-confirmed copy to a detected Trash folder, followed by deletion from source.
- Password kept in process memory only; no credential persistence.

## Fixes in this revision
- Added exact DTI IMAP1 and IMAP2 domain routing, including `eurus.dti.ne.jp` → `imap.cm.dream.jp`.
- Removed the Android/JavaMail `Message` class-name collision.
- Added safe handling for message read-flag checks and more useful nested connection error messages.
- Kept TLS certificate and server-identity verification enabled.

## Limitations / security
This is a starter port, not a feature-identical or verified release. It currently reads messages as text (HTML is converted to text; no rich HTML viewer, inline CID images, attachment downloads, folder picker, OAuth, or multi-account support). Some providers require app passwords or OAuth; Microsoft 365 OAuth is not implemented. Provider mapping and IMAP behavior have not been live-authentication tested. The DTI mapping is copied from the included Windows source table; account credentials, service eligibility, and provider-side IMAP access can still cause login failures. Trash folder naming varies by provider. Do not share email passwords in chat or public repositories. The debug APK is for testing, not Play Store distribution.
