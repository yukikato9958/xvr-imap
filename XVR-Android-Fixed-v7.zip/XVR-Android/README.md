# XVR Mail Android — test build

Native Android Java IMAP client source project. This is a test build, not a production-verified mail client.

## Build from an Android phone with GitHub Actions
1. Extract this ZIP on your phone.
2. Upload the **contents** of the `XVR-Android` folder to the repository root (the `app`, `.github`, `build.gradle`, `settings.gradle`, and `gradle.properties` entries must be directly at the repository root).
3. Open the repository's **Actions** tab, choose **Build XVR APK**, and tap **Run workflow**.
4. When the run succeeds, open it and download the `XVR-debug-APK` artifact. Extract the downloaded artifact ZIP to get the APK.

The workflow uses Java 17 and Gradle 8.9. Android SDK/build execution happens on GitHub's hosted runner.

## Implemented in this test build
- Dark UI and IMAPS connection on port 993 with TLS certificate/hostname verification.
- Provider map including DTI legacy domain routing; `eurus.dti.ne.jp` maps to `imap.cm.dream.jp`.
- Inbox, Sent, Draft, Spam, Trash, and All Mail folder-name discovery where the provider exposes matching folders.
- Latest-message paging and server-side search by sender or subject (up to 100 search results displayed).
- Text view and optional HTML view; remote images remain blocked until the user explicitly confirms loading them.
- Reply/forward/compose hand off to another email app on the phone; this app does not send SMTP itself.
- Sender photos are looked up only in the phone's local contacts, with initials as fallback.
- Credentials are held in process memory and are not saved to disk.

## Fixes in this revision
- Folder discovery now reconnects before querying the IMAP server.
- Folder aliases (such as `SENT` and `TRASH`) are resolved to real server folder names before opening or moving messages.
- Provider folder state no longer overwrites the selected UI folder key.
- Failed IMAP operations invalidate a stale connection so the next action can reconnect.
- Trash folder is closed after the copy operation.
- Message body extraction skips attachment parts.
- Search display is capped at 100 results to avoid rendering an unbounded list.
- Proton Mail is no longer incorrectly mapped to localhost; it requires Proton Mail Bridge or a user-supplied compatible IMAP server.

## Not yet verified / limitations
- This source has not been built with the Android SDK in this environment. Run the GitHub Actions workflow to verify compilation and APK packaging.
- No live account login, real IMAP search, message reading, folder compatibility, or delete/move operation has been tested against an actual provider.
- Search checks sender and subject, not message body.
- Provider folder names vary; some providers do not expose All Mail, Spam, or Trash.
- Some providers require app passwords or OAuth. OAuth is not implemented.
- Compose, reply, and forward open another mail app; sending is not handled inside XVR.
- HTML display is a basic WebView view. Remote content can reveal IP/activity after explicit approval; do not load images from untrusted senders.
- Debug APK is for testing, not Play Store release.
