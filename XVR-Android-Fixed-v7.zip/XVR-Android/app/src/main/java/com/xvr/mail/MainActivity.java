package com.xvr.mail;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import android.text.InputType;
import android.content.res.ColorStateList;
import android.content.Intent;
import android.net.Uri;
import android.provider.ContactsContract;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import java.util.*;
import java.util.concurrent.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.search.*;

public class MainActivity extends Activity {
 private final ExecutorService worker=Executors.newSingleThreadExecutor();
 private LinearLayout root,content,listBox; private EditText email,password,username,server,search;
 private TextView status; private Store store; private Folder current;
 private String account="",pass="",imapHost="",imapUser="",folderName="INBOX",messageHtml="",messageText="",messageSubject="";
 private int shown=30; private boolean showImages=false; private final int CONTACTS_REQ=77;
 private final int BG=Color.rgb(15,16,21),PANEL=Color.rgb(29,31,39),FG=Color.rgb(239,241,247),MUTED=Color.rgb(155,162,178),BLUE=Color.rgb(25,119,245);
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.READ_CONTACTS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.READ_CONTACTS},CONTACTS_REQ);loginScreen();}
 private TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(FG);t.setTextSize(size);t.setPadding(0,8,0,8);return t;}
 private Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setTextColor(FG);b.setAllCaps(false);b.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(43,55,78)));b.setOnClickListener(v->r.run());return b;}
 private EditText field(String hint,boolean secret){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(FG);e.setTextSize(15);e.setPadding(14,8,14,8);e.setBackgroundColor(PANEL);if(secret)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=9;content.addView(e,p);return e;}
 private void base(String title){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(16,12,16,8);root.setBackgroundColor(BG);setContentView(root);root.addView(label(title,23));status=label("Siap",12);status.setTextColor(MUTED);root.addView(status);ScrollView sc=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(1);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));}
 private void say(String s){runOnUiThread(()->{if(status!=null)status.setText(s);});}
 private void loginScreen(){base("XVR Mail");content.addView(label("IMAP EMAIL",12));email=field("Alamat email",false);password=field("Password / app password",true);username=field("IMAP username (opsional)",false);server=field("Custom IMAP server (opsional)",false);content.addView(button("HUBUNGKAN KE EMAIL",()->connect()));content.addView(label("Koneksi IMAP dengan TLS • Kata sandi tidak disimpan",12));}
 private void connect(){account=email.getText().toString().trim();pass=password.getText().toString();String u=username.getText().toString().trim(),h=server.getText().toString().trim();if(account.isEmpty()||pass.isEmpty()){say("Masukkan email dan password");return;}if(u.isEmpty())u=account;if(h.isEmpty())h=ProviderMap.host(account);if(h.isEmpty()){say("Proton Mail memerlukan Proton Mail Bridge atau server IMAP khusus. Isi Custom IMAP server.");return;}imapUser=u;imapHost=h;say("Menghubungkan ke "+h+" …");worker.execute(()->{try{reconnectStore();runOnUiThread(()->mailScreen("INBOX"));}catch(Exception e){say("Koneksi gagal: "+safe(e));}});}
 private void reconnectStore()throws Exception{if(store!=null&&store.isConnected())return;try{if(store!=null)store.close();}catch(Exception ignored){}Properties p=new Properties();p.put("mail.store.protocol","imaps");p.put("mail.imaps.host",imapHost);p.put("mail.imaps.port","993");p.put("mail.imaps.ssl.enable","true");p.put("mail.imaps.ssl.checkserveridentity","true");p.put("mail.imaps.ssl.protocols","TLSv1.2 TLSv1.3");p.put("mail.imaps.connectiontimeout","20000");p.put("mail.imaps.timeout","30000");p.put("mail.imaps.writetimeout","30000");Session s=Session.getInstance(p);Store fresh=s.getStore("imaps");fresh.connect(imapHost,imapUser,pass);store=fresh;}
 private void invalidateConnection(){try{closeCurrent();if(store!=null)store.close();}catch(Exception ignored){}store=null;}
 private String safe(Exception e){StringBuilder b=new StringBuilder();Throwable t=e;int n=0;while(t!=null&&n++<5){if(t.getMessage()!=null&&!t.getMessage().trim().isEmpty()){if(b.length()>0)b.append(" | ");b.append(t.getMessage().trim());}t=t.getCause();}return b.length()==0?e.getClass().getSimpleName():b.toString();}
 private void closeCurrent(){try{if(current!=null&&current.isOpen())current.close(false);}catch(Exception ignored){}current=null;}
 private Folder openFolder(String name)throws Exception{reconnectStore();closeCurrent();Folder f=store.getFolder(name);if(!f.exists())throw new Exception("Folder tidak ditemukan: "+name);f.open(Folder.READ_WRITE);current=f;return f;}
 private void mailScreen(String selected){
  folderName=selected; base("XVR");
  LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(0,2,0,8);
  TextView logo=label("✉",30); logo.setTextColor(Color.rgb(30,135,255)); top.addView(logo);
  LinearLayout brand=new LinearLayout(this); brand.setOrientation(1); TextView heading=label("XVR Mail",21); heading.setTypeface(null,1); brand.addView(heading); TextView sub=label("Secure • Fast • Offline",10); sub.setTextColor(MUTED); brand.addView(sub); top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
  top.addView(button("⋮",()->moreMenu())); content.addView(top);
  TextView accountLine=label(account,11); accountLine.setTextColor(MUTED); content.addView(accountLine);
  search=new EditText(this); search.setSingleLine(true); search.setHint("Cari email, pengirim, atau subjek"); search.setTextColor(FG); search.setHintTextColor(MUTED); search.setPadding(16,10,16,10); search.setBackground(makeRound(PANEL,18)); content.addView(search,new LinearLayout.LayoutParams(-1,-2));
  LinearLayout actions=new LinearLayout(this); actions.setOrientation(0);
  Button find=button("⌕ Cari",()->load(true)); actions.addView(find,new LinearLayout.LayoutParams(0,-2,1));
  Button refresh=button("↻ Refresh",()->load(false)); actions.addView(refresh,new LinearLayout.LayoutParams(0,-2,1)); content.addView(actions);
  HorizontalScrollView chipsScroll=new HorizontalScrollView(this); chipsScroll.setHorizontalScrollBarEnabled(false); LinearLayout chips=new LinearLayout(this); chips.setOrientation(0);
  String[][] chipItems={{"Inbox","INBOX"},{"Sent","SENT"},{"Draft","DRAFT"},{"Spam","SPAM"},{"Trash","TRASH"},{"All","ALL"}};
  for(String[] item:chipItems){Button chip=button(item[0],()->{shown=30;mailScreen(item[1]);});chip.setTextSize(12);chip.setBackgroundTintList(ColorStateList.valueOf(selected.equals(item[1])?BLUE:PANEL));LinearLayout.LayoutParams chipP=new LinearLayout.LayoutParams(-2,-2);chipP.rightMargin=6;chips.addView(chip,chipP);} chipsScroll.addView(chips);content.addView(chipsScroll);
  TextView section=label(folderTitle(selected),19); section.setTypeface(null,1); content.addView(section);
  TextView hint=label("Pesan terbaru",12); hint.setTextColor(MUTED); content.addView(hint);
  listBox=new LinearLayout(this); listBox.setOrientation(1); content.addView(listBox);
  content.addView(button("Muat 30 email lagi",()->{shown+=30;load(false);}));
  LinearLayout nav=new LinearLayout(this); nav.setOrientation(0); nav.setGravity(Gravity.CENTER); nav.setPadding(2,8,2,4); nav.setBackgroundColor(PANEL);
  String[][] navs={{"✉\nEmail","INBOX"},{"⌕\nSearch","SEARCH"},{"▣\nTrash","TRASH"},{"•••\nMore","MORE"}};
  for(String[] n:navs){ final String key=n[1]; TextView t=label(n[0],11); t.setGravity(Gravity.CENTER); t.setPadding(3,7,3,7); t.setTextColor((selected.equals(key)||("INBOX".equals(key)&&selected.equals("INBOX")))?Color.rgb(104,164,255):FG); t.setOnClickListener(v->{if(key.equals("SEARCH")){search.requestFocus();((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(search,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);}else if(key.equals("MORE"))moreMenu();else{shown=30;mailScreen(key);}}); nav.addView(t,new LinearLayout.LayoutParams(0,-2,1)); }
  root.addView(nav,new LinearLayout.LayoutParams(-1,-2));
  Button compose=button("✎  Tulis Email",()->compose("","","")); compose.setBackgroundTintList(ColorStateList.valueOf(BLUE)); root.addView(compose,new LinearLayout.LayoutParams(-1,-2));
  load(false);
 }
 private void moreMenu(){String[] opts={"All Mail","Pengaturan","Keluar"};new AlertDialog.Builder(this).setTitle("XVR Mail").setItems(opts,(d,w)->{if(w==0){mailScreen("ALL");}else if(w==1){settingsScreen();}else disconnect();}).show();}
 private void settingsScreen(){base("Pengaturan");content.addView(label("Akun Email",18));content.addView(label(account,14));content.addView(label("Privasi gambar",16));content.addView(label("Gambar eksternal selalu diblokir secara default. Setiap email meminta persetujuan sebelum gambar dimuat.",13));content.addView(button("Kembali",()->mailScreen(folderName)));content.addView(button("Keluar dari akun",()->disconnect()));}
 private void compose(String to,String subject,String body){try{Intent i=new Intent(Intent.ACTION_SENDTO);i.setData(Uri.parse("mailto:"));if(to!=null&&!to.isEmpty())i.putExtra(Intent.EXTRA_EMAIL,new String[]{to});if(subject!=null)i.putExtra(Intent.EXTRA_SUBJECT,subject);if(body!=null)i.putExtra(Intent.EXTRA_TEXT,body);startActivity(i);}catch(Exception e){say("Tidak ada aplikasi email untuk menulis pesan");}}
 private String initials(String text){if(text==null||text.trim().isEmpty())return "?";String v=text.trim();int at=v.indexOf('<');if(at>0)v=v.substring(0,at).trim();String[] parts=v.split("[\\s@._-]+");String a=parts.length>0?parts[0]:v;String b=parts.length>1?parts[1]:"";return (a.substring(0,1)+(b.isEmpty()?"":b.substring(0,1))).toUpperCase(Locale.ROOT);}
 private View senderAvatar(String from,int size){FrameLayout box=new FrameLayout(this);box.setLayoutParams(new LinearLayout.LayoutParams(size,size));TextView initials=new TextView(this);initials.setText(initials(from));initials.setTextColor(Color.WHITE);initials.setTextSize(17);initials.setTypeface(null,1);initials.setGravity(Gravity.CENTER);GradientDrawable bg=new GradientDrawable();int[] colors={0xff0878f9,0xff7c3aed,0xff0d9488,0xffea580c,0xffdb2777,0xff4f46e5};bg.setColor(colors[Math.floorMod((from==null?0:from.hashCode()),colors.length)]);bg.setShape(GradientDrawable.OVAL);initials.setBackground(bg);box.addView(initials,new FrameLayout.LayoutParams(-1,-1));Bitmap photo=contactPhoto(from);if(photo!=null){android.widget.ImageView image=new android.widget.ImageView(this);image.setImageBitmap(photo);image.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);image.setBackground(circle);image.setClipToOutline(true);box.addView(image,new FrameLayout.LayoutParams(-1,-1));}return box;}
 private Bitmap contactPhoto(String from){if(from==null)return null;try{java.util.regex.Matcher m=java.util.regex.Pattern.compile("<([^>]+)>").matcher(from);String addr=m.find()?m.group(1):from.trim();if(!addr.contains("@")||checkSelfPermission(android.Manifest.permission.READ_CONTACTS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return null;Uri uri=Uri.withAppendedPath(ContactsContract.CommonDataKinds.Email.CONTENT_FILTER_URI,Uri.encode(addr));try(Cursor c=getContentResolver().query(uri,new String[]{ContactsContract.CommonDataKinds.Photo.PHOTO},null,null,null)){if(c!=null&&c.moveToFirst()&&!c.isNull(0)){byte[] data=c.getBlob(0);return BitmapFactory.decodeByteArray(data,0,data.length);}}}catch(Exception ignored){}return null;}
 private String folderTitle(String key){switch(key){case "INBOX":return "Inbox";case "SENT":return "Sent";case "DRAFT":return "Drafts";case "SPAM":return "Spam";case "TRASH":return "Trash";default:return "All Mail";}}
 private android.graphics.drawable.GradientDrawable makeRound(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(radius);d.setStroke(1,Color.rgb(48,54,68));return d;}
 private String resolveFolder(String key)throws Exception{reconnectStore();if(key.equals("INBOX"))return "INBOX";Folder[] fs=store.getDefaultFolder().list("*");String[] needles;switch(key){case "ALL":needles=new String[]{"all mail","[gmail]/all mail"};break;case "SENT":needles=new String[]{"sent","sent items","sent messages","[gmail]/sent mail"};break;case "DRAFT":needles=new String[]{"draft","drafts","[gmail]/drafts"};break;case "SPAM":needles=new String[]{"spam","junk","[gmail]/spam"};break;case "TRASH":needles=new String[]{"trash","deleted items","[gmail]/trash"};break;default:needles=new String[]{"all mail","[gmail]/all mail"};}
 for(Folder f:fs){String n=f.getFullName().toLowerCase(Locale.ROOT);for(String x:needles)if(n.equals(x)||n.endsWith("/"+x)||n.endsWith(x))return f.getFullName();}throw new Exception("Folder "+key+" tidak tersedia pada provider email ini");}
 private static class MailRow { int number; String subject,from,date; boolean seen; MailRow(int n,String s,String f,String d,boolean r){number=n;subject=s;from=f;date=d;seen=r;} }
 private void load(boolean doSearch){
  final String key=folderName; final String query=doSearch&&search!=null?search.getText().toString().trim():""; say("Memuat "+folderTitle(key)+"…");
  worker.execute(()->{try{
   String real=resolveFolder(key); Folder f=openFolder(real); int total=f.getMessageCount(); Message[] msgs;
   if(!query.isEmpty()) {msgs=f.search(new OrTerm(new SubjectTerm(query),new FromStringTerm(query)));if(msgs.length>100)msgs=Arrays.copyOfRange(msgs,msgs.length-100,msgs.length);}
   else {int start=Math.max(1,total-shown+1);msgs=total==0?new Message[0]:f.getMessages(start,total);}
   List<MailRow> rows=new ArrayList<>();
   for(int i=msgs.length-1;i>=0;i--){Message m=msgs[i];String subject="(Tanpa subjek)",from="",date="";boolean seen=false;
    try{if(m.getSubject()!=null)subject=m.getSubject();Address[] a=m.getFrom();if(a!=null&&a.length>0)from=a[0].toString();if(m.getReceivedDate()!=null)date=m.getReceivedDate().toString();seen=m.isSet(Flags.Flag.SEEN);}catch(Exception ignored){}
    rows.add(new MailRow(m.getMessageNumber(),subject,from,date,seen));
   }
   final int count=total; runOnUiThread(()->{if(listBox==null)return;listBox.removeAllViews();
    if(rows.isEmpty()){TextView empty=label("Tidak ada email untuk ditampilkan",14);empty.setGravity(Gravity.CENTER);empty.setPadding(12,28,12,28);listBox.addView(empty);}
    for(MailRow row:rows){LinearLayout card=new LinearLayout(this);card.setOrientation(0);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(12,12,12,12);card.setBackground(makeRound(PANEL,16));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=8;listBox.addView(card,cp);
     card.addView(senderAvatar(row.from,48),new LinearLayout.LayoutParams(48,48));LinearLayout details=new LinearLayout(this);details.setOrientation(1);details.setPadding(12,0,0,0);card.addView(details,new LinearLayout.LayoutParams(0,-2,1));
     TextView from=label(row.from.isEmpty()?"Pengirim tidak diketahui":row.from,13);from.setTextColor(FG);from.setTypeface(null,row.seen?0:1);details.addView(from);
     TextView subject=label(row.subject,15);subject.setTypeface(null,row.seen?0:1);details.addView(subject);
     TextView date=label(row.date,10);date.setTextColor(MUTED);details.addView(date);
     TextView unread=label(row.seen?"":"●",13);unread.setTextColor(BLUE);card.addView(unread);
     card.setOnClickListener(v->showMessage(row.number,key));
    }
    say(rows.size()+" email ditampilkan • "+count+" total");
   });
  }catch(Exception e){invalidateConnection();say("Gagal memuat: "+safe(e)+". Coba Refresh untuk menyambungkan ulang.");}});
 }
 private static class Bodies{String plain="",html="";}
 private void extract(Part p,Bodies out)throws Exception{Object c=p.getContent();if(c instanceof String){String s=(String)c;if(p.isMimeType("text/html"))out.html=s;else if(p.isMimeType("text/plain"))out.plain=s;}else if(c instanceof Multipart){Multipart mp=(Multipart)c;for(int i=0;i<mp.getCount();i++){Part part=mp.getBodyPart(i);String disposition=part.getDisposition();if(Part.ATTACHMENT.equalsIgnoreCase(disposition))continue;if(part.isMimeType("multipart/*"))extract(part,out);else if((part.isMimeType("text/plain")||part.isMimeType("text/html"))&&!Part.ATTACHMENT.equalsIgnoreCase(disposition))extract(part,out);}}}
 private void showMessage(int number,String folder){say("Membuka email…");worker.execute(()->{try{Folder f=openFolder(resolveFolder(folder));Message m=f.getMessage(number);String subj=m.getSubject()==null?"(Tanpa subjek)":m.getSubject();String from=m.getFrom()==null?"":Arrays.toString(m.getFrom());Bodies bodies=new Bodies();extract(m,bodies);String plain=bodies.plain;if(plain.isEmpty()&& !bodies.html.isEmpty())plain=android.text.Html.fromHtml(bodies.html,android.text.Html.FROM_HTML_MODE_COMPACT).toString();if(plain.isEmpty())plain="[Email tidak memiliki isi teks yang dapat ditampilkan]";final String html=bodies.html,txt=plain;runOnUiThread(()->messageScreen(subj,from,html,txt,number,folder));}catch(Exception e){invalidateConnection();say("Gagal membaca email: "+safe(e)+". Coba buka kembali email.");}});}
 private void messageScreen(String subj,String from,String html,String txt,int number,String folder){
  messageHtml=html; messageText=txt; messageSubject=subj; showImages=false; base("XVR");
  content.addView(button("← Kembali ke "+folderTitle(folder),()->mailScreen(folder)));
  TextView title=label(subj,21); title.setTypeface(null,1); content.addView(title);
  TextView sender=label("Dari  "+from,13); sender.setTextColor(MUTED); content.addView(sender);
  TextView privacy=label("Gambar eksternal diblokir untuk privasi",12); privacy.setTextColor(Color.rgb(244,190,90)); content.addView(privacy);
  LinearLayout choices=new LinearLayout(this); choices.setOrientation(0);
  choices.addView(button("Hanya Teks",()->renderBody(false)),new LinearLayout.LayoutParams(0,-2,1));
  choices.addView(button("Tampilkan Gambar",()->new AlertDialog.Builder(this).setTitle("Muat gambar eksternal?").setMessage("Gambar dari server luar dapat mengungkap alamat IP dan aktivitas membaca email. Lanjutkan hanya jika kamu percaya pengirimnya.").setNegativeButton("Batal",(d,w)->{}).setPositiveButton("Tampilkan",(d,w)->renderBody(true)).show()),new LinearLayout.LayoutParams(0,-2,1));
  content.addView(choices);
  FrameLayout frame=new FrameLayout(this); frame.setId(android.R.id.custom); content.addView(frame,new LinearLayout.LayoutParams(-1,0,1)); renderBody(false,frame);
  LinearLayout messageActions=new LinearLayout(this);messageActions.setOrientation(0);content.addView(messageActions);messageActions.addView(button("↶ Balas",()->compose(extractAddress(from),"Re: "+subj,"\n\n--- Pesan sebelumnya ---\n"+txt)),new LinearLayout.LayoutParams(0,-2,1));messageActions.addView(button("Teruskan",()->compose("","Fwd: "+subj,"\n\n--- Pesan diteruskan ---\n"+txt)),new LinearLayout.LayoutParams(0,-2,1));
  content.addView(button("Hapus ke Trash",()->moveTrash(number,folder)));
  say("Email dibuka • gambar eksternal diblokir");
 }
 private void renderBody(boolean images){showImages=images;View old=findViewById(android.R.id.custom);if(!(old instanceof FrameLayout))return;renderBody(images,(FrameLayout)old);}
 private void renderBody(boolean images,FrameLayout frame){
  frame.removeAllViews();
  if(!images||messageHtml.isEmpty()) {TextView t=label(messageText,15);t.setTextIsSelectable(true);t.setPadding(4,12,4,12);frame.addView(t);return;}
  WebView web=new WebView(this); WebSettings settings=web.getSettings(); settings.setJavaScriptEnabled(false); settings.setLoadsImagesAutomatically(true); settings.setBlockNetworkImage(false); settings.setDomStorageEnabled(false); settings.setAllowFileAccess(false); web.setBackgroundColor(BG);
  String safeHtml=messageHtml.replaceAll("(?i)<script[^>]*>[\\s\\S]*?</script>","");
  web.loadDataWithBaseURL("https://xvr.invalid/",safeHtml,"text/html","UTF-8",null); frame.addView(web,new FrameLayout.LayoutParams(-1,-1));
 }
 private void moveTrash(int number,String source){say("Memindahkan email…");worker.execute(()->{Folder trash=null;try{Folder src=openFolder(resolveFolder(source));Message m=src.getMessage(number);String trashName=resolveFolder("TRASH");trash=store.getFolder(trashName);if(!trash.isOpen())trash.open(Folder.READ_WRITE);src.copyMessages(new Message[]{m},trash);m.setFlag(Flags.Flag.DELETED,true);src.expunge();say("Email dipindahkan ke Trash");runOnUiThread(()->mailScreen(source));}catch(Exception e){invalidateConnection();say("Gagal menghapus: "+safe(e)+". Koneksi akan dicoba ulang saat tindakan berikutnya.");}finally{try{if(trash!=null&&trash.isOpen())trash.close(false);}catch(Exception ignored){}}});}
 private String extractAddress(String from){if(from==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("<([^>]+)>").matcher(from);return m.find()?m.group(1):from.trim();}
 private void disconnect(){worker.execute(()->{try{closeCurrent();if(store!=null)store.close();}catch(Exception ignored){}store=null;runOnUiThread(()->loginScreen());});}
 @Override protected void onDestroy(){super.onDestroy();worker.execute(()->{try{closeCurrent();if(store!=null)store.close();}catch(Exception ignored){}store=null;});worker.shutdown();}
}
